$(function(e){
	$('.counter').countUp();
});