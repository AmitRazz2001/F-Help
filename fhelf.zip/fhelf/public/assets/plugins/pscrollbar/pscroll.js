(function($) {
	"use strict";	
	// ______________ PerfectScrollbar	
	const ps = new PerfectScrollbar('.app-sidebar', {
		useBothWheelAxes:true,
		suppressScrollX:true,
	});
	
})(jQuery);