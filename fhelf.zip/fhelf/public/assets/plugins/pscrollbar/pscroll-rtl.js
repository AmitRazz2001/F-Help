(function($) {
	"use strict";	
	// ______________ PerfectScrollbar	
	const ps = new PerfectScrollbar('.app-sidebar', {
		useBothWheelAxes:false,
		suppressScrollX:false,
	});
	
})(jQuery);