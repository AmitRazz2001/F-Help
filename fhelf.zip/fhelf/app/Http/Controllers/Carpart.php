<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class Carpart extends Controller
{
	public function index()
	{
		return view('frontent.index');
	}
	public function part()
	{
		return view('frontent.part');
	}
}
